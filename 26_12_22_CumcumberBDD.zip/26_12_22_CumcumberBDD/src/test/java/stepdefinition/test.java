package stepdefinition;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;



public class test {
	
	public static void main(String[] args) throws InterruptedException  {
	
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\livya\\eclipse-workspace_2022\\Drivers\\chromedriver.exe");
	ChromeOptions option = new ChromeOptions();
    option.setExperimentalOption("useAutomationExtension", false);
    
    WebDriver driver=new ChromeDriver();	
   	driver.get("https://dsportalapp.herokuapp.com/");
   	
   	driver.findElement(By.cssSelector("button[class='btn']")).click();
   	
   	String url=driver.getCurrentUrl();
   	url.equals("https://dsportalapp.herokuapp.com/home");
   	
   	driver.findElement(By.xpath("//a[text()=' Register ']")).click();
   	
   	String registerurl=driver.getCurrentUrl();
   	registerurl.equals("https://dsportalapp.herokuapp.com/register");
   	
   	driver.findElement(By.id("id_username")).sendKeys("Livyakumar7");
   	
   	driver.findElement(By.name("password1")).sendKeys("Password@123");
   	
   	driver.findElement(By.name("password2")).sendKeys("Password@123");
   	
   	driver.findElement(By.xpath("//input[@value='Register']")).click();
   	
	//System.out.println(driver.findElement(By.xpath("//div[@class='alert alert-primary']")).getText());
   	
   	driver.findElement(By.xpath("//div[@class='alert alert-primary']")).equals("New Account Created. You are logged in as Livyakumar7");
   	   
   	//System.out.println(driver.findElement(By.xpath("//a[text()=' Livyakumar7 ']")).getText());
   	
   	driver.findElement(By.xpath("//a[text()=' Livyakumar7 ']")).equals("Livyakumar7");
   	
   	driver.findElement(By.xpath("//a[contains(text(),'Sign out')]")).click();
   	
     	
   	driver.findElement(By.xpath("//div[@class='alert alert-primary']")).equals("Logged out successfully");

	System.out.println(driver.findElement(By.xpath("//div[@class='alert alert-primary']")).getText());

}

}