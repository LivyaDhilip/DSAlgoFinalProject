package stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class Registration_SD {
	
	WebDriver driver=new ChromeDriver();

	@Given("user navigates to the dsportalapp page")
	public void user_navigates_to_the_dsportalapp_page() {
		
	   	driver.get("https://dsportalapp.herokuapp.com/");
	}

	@When("user clicks on {string} button")
	public void user_clicks_on_button(String string) {
		driver.findElement(By.cssSelector("button[class='btn']")).click();
	}

	@Then("user will see the Home page")
	public void user_will_see_the_home_page() {
	String url=driver.getCurrentUrl();
	   	url.equals("https://dsportalapp.herokuapp.com/home");
	}

	@When("user clicks on {string} link")
	public void user_clicks_on_link(String string) {
		driver.findElement(By.xpath("//a[text()=' Register ']")).click();
	}

	@Then("user will be on the Register page")
	public void user_will_be_on_the_register_page() {
		String registerurl=driver.getCurrentUrl();
	   	registerurl.equals("https://dsportalapp.herokuapp.com/register");
	}

	@Then("The user enter the (.*) ,(.*) and (.*)$")
	public void the_user_enter_the_user_name_password_and_confirm_password(String username,String password,String confpassword) throws InterruptedException {
		
	   Thread.sleep(500);
	   	driver.findElement(By.id("id_username")).sendKeys(username);
	   	
	   	driver.findElement(By.name("password1")).sendKeys(password);
	   	
	   	driver.findElement(By.name("password2")).sendKeys(confpassword);
	}
	
	
	@When("user clicks on the {string} button")
	public void user_clicks_on_the_button(String string) {
		driver.findElement(By.xpath("//input[@value='Register']")).click();
	}

	/*@Then("user will get a message as 'New Account Created. You are logged in as 'Livyakumar14'")
	public void user_will_get_a_message_as_new_account_created_you_are_logged_in_as_livyakumar() {
		driver.findElement(By.xpath("//div[@class='alert alert-primary']")).equals("New Account Created. You are logged in as Livyakumar14");
	}

	@Then("user will see the Username and Sign out links at the top of the page")
	public void user_will_see_the_username_and_sign_out_links_at_the_top_of_the_page() {
	   	driver.findElement(By.xpath("//a[text()=' Livyakumar14 ']")).equals("Livyakumar14");
	   	
	}*/

	@When("user clicks on 'Sign Out link")
	public void user_clicks_on_sign_out_link() {
		driver.findElement(By.xpath("//a[contains(text(),'Sign out')]")).click();
	}

	@Then("user will see a message {string} and user is signed out")
	public void user_will_see_a_message_and_user_is_signed_out(String string) {
		driver.findElement(By.xpath("//div[@class='alert alert-primary']")).equals("Logged out successfully");

		System.out.println(driver.findElement(By.xpath("//div[@class='alert alert-primary']")).getText());
	}
/*
	@Given("user on the Sign In page")
	public void user_on_the_sign_in_page() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@When("user enters {string} with {string}")
	public void user_enters_with(String string, String string2) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("user will see a message {string} at the top left of the page")
	public void user_will_see_a_message_at_the_top_left_of_the_page(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("user will see the {string} and {string} links at the top of the page")
	public void user_will_see_the_and_links_at_the_top_of_the_page(String string, String string2) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
*/
}
